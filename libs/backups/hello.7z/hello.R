sayHello <- function(){
	print('hello')
}

sayHello()