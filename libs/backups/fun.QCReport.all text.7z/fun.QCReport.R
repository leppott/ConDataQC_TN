# Sourced Routine
##################
# Generate QC Report
#########################
# Erik.Leppo@tetratech.com (EWL)
# 20151022
###################
# Basic Operations:
# load all files in data directory
# find ones specified by user
# generate QC data summaries
# output to PDF
#####################
## ideas
# load one file instead of all
################

# library (load any required helper functions)
#library(waterData)
library(knitr)

# ##############################
# # 20151221
# # create MD file in myDir.BASE
# # then knit
# # then PANDOC to DOCX
# ####
# # 1. Create MD file
# # 2. Knit MD file
# knit('report_knit_.md')
# # 3. Pandoc, convert MD to DOCX
# pandoc(report.md,-0,"report.docx")
# ##############################



# FUNCTION
fun.QCReport <- function(fun.myData.SiteID
                         ,fun.myData.Type
                         ,fun.myData.DateRange.Start
                         ,fun.myData.DateRange.End
                         ,fun.myDir.BASE
                         ,fun.myDir.SUB.import
                         ,fun.myDir.SUB.export
                         ,fun.myFile.Prefix) {##FUN.fun.QCauto.START
  #
  # Convert Data Type to proper case
  fun.myData.Type <- paste(toupper(substring(fun.myData.Type,1,1)),tolower(substring(fun.myData.Type,2,nchar(fun.myData.Type))),sep="")
  #
  # data directories
  myDir.data.import <- paste(fun.myDir.BASE,ifelse(fun.myDir.SUB.import=="","",paste("/",fun.myDir.SUB.import,sep="")),sep="")
  myDir.data.export <- paste(fun.myDir.BASE,ifelse(fun.myDir.SUB.export=="","",paste("/",fun.myDir.SUB.export,sep="")),sep="")
  #
  myDate <- format(Sys.Date(),"%Y%m%d")
  myTime <- format(Sys.time(),"%H%M%S")
  #
  # Start Time (used to determine run time at end)
  myTime.Start <- Sys.time()
  #
    # 0. Load Single file
    strFile.Prefix     <- toupper(fun.myFile.Prefix)     # DATA = Aggregate, QC = QC
    strFile.SiteID     <- fun.myData.SiteID
    strFile.DataType   <- fun.myData.Type
    strFile.Date.Start <- format(as.Date(fun.myData.DateRange.Start,"%Y-%m-%d"),"%Y%m%d")
    strFile.Date.End   <- format(as.Date(fun.myData.DateRange.End,"%Y-%m-%d"),"%Y%m%d")
    strFile = paste(paste(strFile.Prefix,strFile.SiteID,fun.myData.Type,strFile.Date.Start,strFile.Date.End,sep=myDelim),"csv",sep=".")
    strFile.Base <- substr(strFile,1,nchar(strFile)-nchar(".csv"))
    strFile.parts <- strsplit(strFile.Base,myDelim)
   
    #QC, make sure file exists
    if(strFile %in% list.files(path=myDir.data.import)==FALSE) {##IF.file.START
      #
      print("ERROR; no such file exits.  Cannot create QC Report.")
      print(paste("PATH = ",myDir.data.import,sep=""))
      print(paste("FILE = ",strFile,sep=""))
      flush.console()
      stop("Bad file.")
      #
    }##IF.file.END
    
    #import the file    
    data.import <- read.csv(paste(myDir.data.import,strFile,sep="/"),as.is=TRUE,na.strings="")
    
    
    
    
    
    
    

    
#     ###########################
#     # TEMP
#     ############################
#     # "SINK" output to text file
#     # later on use knitr and Pandoc
#     ###############################
#     strFile.Sink <- paste(myDir.data.export,paste(paste(strFile.Prefix,strFile.SiteID,fun.myData.Type,strFile.Date.Start,strFile.Date.End,"QCReport",sep="_"),"txt",sep="."),sep="/")
#     sink(strFile.Sink, append=FALSE, split=FALSE)
#     ###################################
#     
#     
#    # '''
#     
#     
#     
#     # 1. Header
#     print(myTitle <- "Quality Control Report")
#     print(paste("SiteID: ",strFile.SiteID,sep=""))
#     print(paste("Period of Record, Requested: ",fun.myData.DateRange.Start," to ",fun.myData.DateRange.End,sep=""))
#     myTimeDiff <- difftime(data.import[11,myName.DateTime],data.import[10,myName.DateTime],units="mins")
#     print(paste("Period of Record, Actual: ",min(data.import[,myName.Date])," to ",max(data.import[,myName.Date]),sep=""))
#     print(paste("Recording Interval: ",myTimeDiff[1]," minutes",sep=""))
#     print(paste("Data Type: ",strFile.DataType,sep=""))  # need to do better
#     myParameters <- myNames.DataFields[myNames.DataFields %in% names(data.import)==TRUE] 
#     myParameters.Lab <- myNames.DataFields.Lab[myNames.DataFields %in% names(data.import)==TRUE]
#     cat("Parameters:",myNames.DataFields,sep="\n")
#     myReportDate <- format(Sys.Date(),"%Y-%m-%d")
#     print(paste("QC Report Date: ",myReportDate,sep=""))
#     # 
#     # 2. Data Info, Overall
#     print(myTitle.Sub <- "Data Info, Overall")
#     # 2.1. Records by Month/Day
#     # split so easier to put on paper
#     # number of records by month/day (split 1:15 and 16:31)
#     print(myTable.month.day.rec.LTE15 <- ftable(data.import[,"month"][data.import[,"day"]<=15],data.import[,"day"][data.import[,"day"]<=15]))
#     print(myTable.month.day.rec.GT15 <- ftable(data.import[,"month"][data.import[,"day"]>15],data.import[,"day"][data.import[,"day"]>15]))
#    
#     
#     myTable.month.day.rec <- ftable(data.import[,"month"],data.import[,"day"])
#     # use apply function to count number of records not equal to the expected value
#     
#     
#     # 2.2. Flags
#     print(myTitle.Sub <- "Flags")
#     flags.Num <- c("Number",1,3,4,9)
#     flags.Txt <- c("Text","Pass","Suspect","Fail","Missing Data")
#     print(df.flags <- as.data.frame(rbind(flags.Num,flags.Txt),row.names=NA))
#     print(flags.2 <- "2 = *Not Evaluated* so it is not used.")
#     
#     
# #     # table of flags
# #     (myTable.Flags <- ftable(data.import[,myQCparam.Flag]))
#     
#     #QC
#     # j <- myParameters[1]
#     #
#     for (j in myParameters) {##FOR.j.START
#       #
#       j.num <- match(j,myParameters)
#       print(myParameters.Lab[j.num])
#       print(myTable.Flags.Overall <- table(data.import[,paste("Flag",j,sep=".")]))
#       flush.console()
#       #
#     }##FOR.j.END
#     #
#    #
#  #   strFlags.Desc <- "Data points (a single measured parameter at a unique point in time) flagged as Missing Data (9) if no data (or NA).  If any QC test failed then data point flagged as Fail (4).  Data points without a fail and at least one suspect are flagged as Suspect (3).  Data points with no Fail or Suspect results are flagged as Pass."
#     print("QC Tests")
#     strQCTest.Gross <- "Gross Range Test (Gross).  Test if data point exceeds sensor or user defined min/max.  The values are user defined based on parameter being measured and measuring instrument."
#     strQCTest.Spike <- "Spike Test (Spike).  Test if data point exceeds a user defined threshold relative to the previous data point.  The user defined values are based on the parameter being measured."
#     strQCTest.RoC <- "Rate of Change Test (RoC).  Test if a data point exceeds a number of standard deviations from the previous data points over a user defined time period.  Default is a 25 hour time period and 3 standard deviations."
#     strQCTest.Flat <- "Flat Line Test (Flat).  Test if a data point is within a user defined threshold from previous data points over a user defined range.  Default is 3 previous points for suspect and 5 points for failure.  The threshold is user defined and based on the measured parameter and sensitivity of the measuring instrument."
#     strQCTest.Desc <- "Overall flags assigned by examining the four tests above. 1 = no Fail or Suspect and at least one Pass, 3 = no Fail and at least one Suspect, 4 = at least one Fail, 9 = all tests were Missing Data."
#     #
#     # 3. Data Info, by Parameter
#     # Individual Data Type Report
#     # QC
#     #i <- myParameters[1]
#     for (i in myParameters) {##FOR.i.START
#       #
#       i.num <- match(i,myParameters)
#       print(myTitle.Sub <- myParameters.Lab[i.num])
#       # 3.1. Flags, overall
#       print(myTitle.Sub <- "Flags")
#       print(table(data.import[,paste("Flag",i,sep=".")]))
#       #
#       # 3.1.A Records by Month/Day
#       # split so easier to put on paper
#       # number of records by month/day (split 1:15 and 16:31)
#       # filter for records by parameter that are not NA
#       print(myTable <- ftable(data.import[,"month"][data.import[,"day"]<=15 & !is.na(data.import[,i]) & data.import[,i]!=""],data.import[,"day"][data.import[,"day"]<=15 & !is.na(data.import[,i]) & data.import[,i]!=""]))
#       print(myTable <- ftable(data.import[,"month"][data.import[,"day"]>15 & !is.na(data.import[,i]) & data.import[,i]!=""],data.import[,"day"][data.import[,"day"]>15 & !is.na(data.import[,i]) & data.import[,i]!=""]))
#       #
#       # Convert time interval (minutes) to number per day
#       records.expected <- 24*60/as.numeric(myTimeDiff[1])
#       print(paste("Expected number of records per day is ",records.expected,".",sep=""))
#       # identify days/months where not the expected number of records
#       # (expect first and last day)
#       print("days where not the expected number of records")
#       #
#       # 3.2. Flags by QC Test
#       print(myTitle.Sub <- "Flags by QC Test")
#       print("Flags, Gross")
#       print(myTable.Flags.Gross <- ftable(data.import[,paste("Flag.Gross",i,sep=".")]))
#       print("Flags, Spike")
#       print(myTable.Flags.Spike <- ftable(data.import[,paste("Flag.Spike",i,sep=".")]))
#       print("Flags, RoC")
#       print(myTable.Flags.RoC <- ftable(data.import[,paste("Flag.RoC",i,sep=".")]))
#       print("Flags, Flat")
#       print(myTable.Flags.Flat <- ftable(data.import[,paste("Flag.Flat",i,sep=".")]))
#       print("QC Test Flag fields are saved in the data file so the user can identify data points that have been flagged as suspect or fail.")
#       #
#       #myFlagTests <- c("Gross","Spike","RoC","Flat")
#       #(myTable.Flags.Flat <- ftable(data.import[,paste("Flag",myFlagTests,i,sep=".")]))
#       #
#       print("Test results marked as 9 (Missing Data) if unable to calculate the end point needed for the test.  For example, the first record does not have a previous record for comparis of the Gross QC Test.")
#       print("QC Test flags are saved in the data file.")
#       #
#       # 3.3. Plot
#       data.plot <- data.import
#       #
#       # cheat on Date/Time axis
#       n.Total <- length(data.plot[,myName.Date])
#       pct <- c(20,40,60,80,100)*.01
#       myAT <- c(1,round(n.Total * pct,0))
#       myLab <- data.plot[,myName.Date][myAT]
#       #
#       myPlot.Y <- data.plot[,i]
#       myPlot.Ylab <- myParameters.Lab[i.num]
#       plot(myPlot.Y,type="l",main=fun.myData.SiteID,xlab=myLab.Date,ylab=myPlot.Ylab,col="gray", xaxt="n")
#       axis(1,at=myAT,labels=myLab,tick=TRUE)
#       #
#     }##FOR.i.END
#     
#     
#     # BOTH plots
#     
#     # 3.3. Plot
#     data.plot <- data.import
#     #
#     # cheat on Date/Time axis
#     n.Total <- length(data.plot[,myName.Date])
#     pct <- c(20,40,60,80,100)*.01
#     myAT <- c(1,round(n.Total * pct,0))
#     myLab <- data.plot[,myName.Date][myAT]
#     #
#     
#     
#     ##################################
#     # Need to check for parameters before plot
#     ##################################    
#     
#     # Temp, Air vs. Water
#     if (myName.AirTemp %in% myParameters & myName.WaterTemp %in% myParameters == TRUE){##IF.Temp.START
#       myPlot.Y <- data.plot[,myName.AirTemp]
#       myPlot.Y2 <- data.plot[,myName.WaterTemp]
#       myPlot.Ylab <- myLab.Temp.BOTH
#       plot(myPlot.Y,type="l",main=fun.myData.SiteID,xlab=myLab.Date,ylab=myPlot.Ylab,col="green", xaxt="n")
#       axis(1,at=myAT,labels=myLab,tick=TRUE)
#       lines(myPlot.Y2,type="l",col="blue")
#       legend(x="bottomright",lty=1,col=c("green","blue"),legend=c("air","water"))
#       #
#     }##IF.Temp.END
#     #
#     # Water, Temp vs Level
#     if (myName.WaterTemp %in% myParameters & myName.WaterLevel %in% myParameters == TRUE){##IF.Temp_Level.START
#       par.orig <- par(no.readonly=TRUE) # save original par settings
#         par(oma=c(0,0,0,2))
#         myPlot.Y <- data.plot[,myName.WaterTemp]
#         myPlot.Ylab <- myLab.WaterTemp
#         myPlot.Y2 <- data.plot[,myName.WaterLevel]
#         myPlot.Y2lab <- myLab.WaterLevel
#         plot(myPlot.Y,type="l",main=fun.myData.SiteID,xlab=myLab.Date,ylab=myPlot.Ylab,col="blue", xaxt="n")
#         axis(1,at=myAT,labels=myLab,tick=TRUE)
#         # Add 2nd y axis (2nd color is black)
#         par(new=TRUE)
#         plot(myPlot.Y2,type="l",col="black",axes=FALSE,ann=FALSE)
#         axis(4)
#         mtext(myPlot.Y2lab,side=4,line=2.5)
#       par(par.orig) # return to original par settings
#     }##IF.Temp_Level.END
#     
#    # '''
#     
#     ###########################
#     # TEMP
#     ############################
#     # "SINK" output to text file
#     # later on use knitr and Pandoc
#     ###############################
#     sink()  # return output to terminal
#     ###################################
#     
#     
#     
    
    
    
    #############
    # Test - knitr/Pandoc
    ##############
#     strFile.MD <- "QCReport"
#     strFile.RMD <- paste(fun.myDir.BASE,paste(strFile.MD,"rmd",sep="."),sep="/")
#     strFile.DOCX <- paste(fun.myDir.BASE,fun.myDir.SUB.export,paste(strFile.Prefix,strFile.SiteID,fun.myData.Type,strFile.Date.Start,strFile.Date.End,"QCReport",sep="_"),sep="/")
#     # a. save R code to report.md (above somewhere)
#     # code already saved in MD file in base directory
#     # b. use knitr to convert MD to RMD (RMD includes results of R code included in MD file)
#     knit(paste(fun.myDir.BASE,paste(strFile.MD,"md",sep="."),sep="/"),output=strFile.RMD)
#     # c. Pandoc to convert RMD to DOCX (runs pandoc outside of R)
#     system(paste0("pandoc -o ", strFile.DOCX, ".docx ", strFile.MD, ".rmd"))
    
    

    
    #RStudio help solution 
    # use RMD with embedded code
    # much cleaner DOCX than the 2-step process of MD with knit to RMD with pandoc
    strFile.RMD <- paste(myDir.BASE,"Scripts","QCReport.rmd",sep="/") #"QCReport.rmd"
    strFile.DOCX <- paste(paste(strFile.Prefix,strFile.SiteID,fun.myData.Type,strFile.Date.Start,strFile.Date.End,"QCReport",sep=myDelim),".docx",sep="")
    rmarkdown::render(strFile.RMD,output_file=strFile.DOCX,output_dir=paste(fun.myDir.BASE,fun.myDir.SUB.export,sep="/"))
    
    
    #######################################################################
    
    # Clean up
    rm(data.import)
    rm(data.plot)
    #

  
  ###########################################################################
  #
  #print(paste("Processing of ",intCounter," of ",intCounter.Stop," files complete.",sep=""))
 # files2process[intCounter] #use for troubleshooting if get error
  # inform user task complete with status
  myTime.End <- Sys.time()
#   print(paste("Processing of items (n=",intItems.Total,") finished.  Total time = ",format(difftime(myTime.End,myTime.Start)),".",sep=""))
#   print(paste("Items COMPLETE = ",myItems.Complete,".",sep=""))
#   print(paste("Items SKIPPPED = ",myItems.Skipped,".",sep=""))
    print(paste("Task COMPLETE. QC Report.  Total time = ",format(difftime(myTime.End,myTime.Start)),".",sep=""))
  # User defined parameters
  print(paste("User defined parameters: SiteID (",fun.myData.SiteID,"), Data Type (",fun.myData.Type,"), Date Range (",fun.myData.DateRange.Start," to ",fun.myData.DateRange.End,").",sep=""))
  flush.console()
  #
}##FUN.QCReport.END
  


