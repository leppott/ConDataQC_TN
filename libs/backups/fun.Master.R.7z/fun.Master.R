#!/cygdrive/c/Program Files/R/R-3.3.2patched/bin/R
#
# Master Continuous Data Script
# Will prompt user for what to do
# Erik.Leppo@tetratech.com
# 20151118
#################
# Master Functions Script that is invoked from a calling the master script
# The master will have different versions but will all call this one.
#


#
# Function - Master
# Run different scripts depending upon user input
#
fun.Master <- function(fun.myData.Operation
                      ,fun.myData.SiteID
                      ,fun.myData.Type
                      ,fun.myData.DateRange.Start
                      ,fun.myData.DateRange.End
                      ,fun.myDir.BASE
                      ,fun.myDir.SUB.import
                      ,fun.myDir.SUB.export)
  {
  #
  # Error checking.  If any null then kick back
  #


  #
  # 20151202, default directories
  #
  # Run different functions based on "fun.myOperation"
  if (fun.myData.Operation == "GetGageData")
  {
    if (fun.myDir.SUB.import=="") {fun.myDir.SUB.import=myName.Dir.1Raw}
    if (fun.myDir.SUB.export=="") {fun.myDir.SUB.export = myName.Dir.1Raw}

    # runs the ReportQC as part of sourced function but can run independantly below
    fun.myData.Type <- "Gage"
    fun.GageData(fun.myData.SiteID
                 ,fun.myData.Type
                 ,fun.myData.DateRange.Start
                 ,fun.myData.DateRange.End
                 ,fun.myDir.BASE
                 ,fun.myDir.SUB.import
                 ,fun.myDir.SUB.export)

  }
  else if (fun.myData.Operation=="QCRaw")
  {
    if (fun.myDir.SUB.import == "") { fun.myDir.SUB.import = myName.Dir.1Raw }
    if (fun.myDir.SUB.export == "") { fun.myDir.SUB.export = myName.Dir.2QC }

    # runs the ReportQC as part of sourced function but can run independently below
    fun.QC(fun.myData.SiteID
           ,fun.myData.Type
           ,fun.myData.DateRange.Start
           ,fun.myData.DateRange.End
           ,fun.myDir.BASE
           ,fun.myDir.SUB.import
           ,fun.myDir.SUB.export)
  }
  else if (fun.myData.Operation=="ReportQC")
  {
    if (fun.myDir.SUB.import=="") {fun.myDir.SUB.import=myName.Dir.2QC}
    if (fun.myDir.SUB.export=="") {fun.myDir.SUB.export=myName.Dir.2QC}

    myProcedure.Step <- "QC"
    fun.Report(fun.myData.SiteID
                 ,fun.myData.Type
                 ,fun.myData.DateRange.Start
                 ,fun.myData.DateRange.End
                 ,fun.myDir.BASE
                 ,fun.myDir.SUB.import
                 ,fun.myDir.SUB.export
                 ,myProcedure.Step)
  }
  else if (fun.myData.Operation=="Aggregate")
  {
    if (fun.myDir.SUB.import=="") {fun.myDir.SUB.import=myName.Dir.2QC}
    if (fun.myDir.SUB.export=="") {fun.myDir.SUB.export=myName.Dir.3Agg}

    fun.AggregateData(fun.myData.SiteID
                      ,fun.myData.Type
                      ,fun.myData.DateRange.Start
                      ,fun.myData.DateRange.End
                      ,fun.myDir.BASE
                      ,fun.myDir.SUB.import
                      ,fun.myDir.SUB.export)
  }
  else if (fun.myData.Operation=="ReportAggregate")
  {
    if (fun.myDir.SUB.import=="") {fun.myDir.SUB.import=myName.Dir.3Agg}
    if (fun.myDir.SUB.export=="") {fun.myDir.SUB.export=myName.Dir.3Agg}

    myProcedure.Step <- "DATA"
    fun.Report(fun.myData.SiteID
                 ,fun.myData.Type
                 ,fun.myData.DateRange.Start
                 ,fun.myData.DateRange.End
                 ,fun.myDir.BASE
                 ,fun.myDir.SUB.import
                 ,fun.myDir.SUB.export
                 ,myProcedure.Step)
  }
  else if (fun.myData.Operation=="SummaryStats")
  {
    if (fun.myDir.SUB.import=="") {fun.myDir.SUB.import=myName.Dir.3Agg}
    if (fun.myDir.SUB.export=="") {fun.myDir.SUB.export=myName.Dir.4Stats}

    myProcedure.Step <- "STATS"
    fun.myFile.Prefix <- "DATA"

    fun.Stats(fun.myData.SiteID
              ,fun.myData.Type
              ,fun.myData.DateRange.Start
              ,fun.myData.DateRange.End
              ,fun.myDir.BASE
              ,fun.myDir.SUB.import
              ,fun.myDir.SUB.export
              ,myProcedure.Step
              ,fun.myFile.Prefix)
  }
  else
  {
    myMsg <- "No operation provided."
    stop(myMsg)
  }
}

####################################################################

########
# QC
########
# fun.myData.SiteID <- myData.SiteID
# fun.myData.Type <- myData.Type
# fun.myData.DateRange.Start <- myData.DateRange.Start
# fun.myData.DateRange.End <- myData.DateRange.End
# fun.myDir.BASE <- myDir.BASE
# fun.myDir.SUB.import <- myDir.SUB.import
# fun.myDir.SUB.export <- myDir.SUB.export
#
# rm(myData.SiteID)
# rm(myData.Type)
# rm(myData.DateRange.Start)
# rm(myData.DateRange.End)
# rm(myDir.SUB.import)
# rm(myDir.SUB.export)









