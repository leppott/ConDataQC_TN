# Sourced Routine
##################
# Statistical Summary
##################
# Erik.Leppo@tetratech.com (EWL)
# 20151120
##################
#
# Basic Operations:
# load all files in data directory
# perform Stats
# write Stat summary file


# library (load any required helper functions)
# library(StreamThermal)
# require(doBy)
# should have been loaded by master script


fun.Stats <- function(fun.myData.SiteID
                     ,fun.myData.Type
                     ,fun.myData.DateRange.Start
                     ,fun.myData.DateRange.End
                     ,fun.myDir.BASE
                     ,fun.myDir.SUB.import
                     ,fun.myDir.SUB.export
                     ,fun.myProcedure.Step
                     ,fun.myFile.Prefix) {##FUN.fun.Stats.START
  #
  ##########
  # QC
  ##########
  if (fun.myDir.SUB.import=="") {fun.myDir.SUB.import=myName.Dir.3Agg}
  if (fun.myDir.SUB.export=="") {fun.myDir.SUB.export=myName.Dir.4Stats}
  myProcedure.Step <- "STATS"
  fun.myFile.Prefix <- "DATA"
  #
  # Error Checking - only 1 SiteID and 1 DataType
  if(length(fun.myData.SiteID)!=1){
    myMsg <- "Function can only handle 1 SiteID."
    stop(myMsg)
  }
  if(length(fun.myData.Type)!=1){
    myMsg <- "Function can only handle 1 Data Type."
    stop(myMsg)
  }
  #
  # Convert Data Type to proper case
  fun.myData.Type <- paste(toupper(substring(fun.myData.Type,1,1)),tolower(substring(fun.myData.Type,2,nchar(fun.myData.Type))),sep="")
  #
  # data directories
  myDir.data.import <- paste(fun.myDir.BASE,ifelse(fun.myDir.SUB.import=="","",paste("/",fun.myDir.SUB.import,sep="")),sep="")
  myDir.data.export <- paste(fun.myDir.BASE,ifelse(fun.myDir.SUB.export=="","",paste("/",fun.myDir.SUB.export,sep="")),sep="")
  #
  myDate <- format(Sys.Date(),"%Y%m%d")
  myTime <- format(Sys.time(),"%H%M%S")
  #  
  # Verify input dates, if blank, NA, or null use all data
  # if DateRange.Start is null or "" then assign it 1900-01-01
  if (is.na(fun.myData.DateRange.Start)==TRUE||fun.myData.DateRange.Start==""){fun.myData.DateRange.Start<-DateRange.Start.Default}
  # if DateRange.End is null or "" then assign it today
  if (is.na(fun.myData.DateRange.End)==TRUE||fun.myData.DateRange.End==""){fun.myData.DateRange.End<-DateRange.End.Default}
  #
  # 0. Load Single file
  strFile.Prefix     <- toupper(fun.myFile.Prefix)     # DATA = Aggregate, QC = QC
  strFile.SiteID     <- fun.myData.SiteID
  strFile.DataType   <- fun.myData.Type
  strFile.Date.Start <- format(as.Date(fun.myData.DateRange.Start,"%Y-%m-%d"),"%Y%m%d")
  strFile.Date.End   <- format(as.Date(fun.myData.DateRange.End,"%Y-%m-%d"),"%Y%m%d")
  strFile <- paste(paste(strFile.Prefix,strFile.SiteID,fun.myData.Type,strFile.Date.Start,strFile.Date.End,sep="_"),"csv",sep=".")
  strFile.Base <- substr(strFile,1,nchar(strFile)-nchar(".csv"))
  strFile.parts <- strsplit(strFile.Base,"_")
  #
  #QC, make sure file exists
  if(strFile %in% list.files(path=myDir.data.import)==FALSE) {##IF.file.START
    #
    print("ERROR; no such file exits.  Cannot generate summary statistics.")
    print(paste("PATH = ",myDir.data.import,sep=""))
    print(paste("FILE = ",strFile,sep=""))
    flush.console()
    stop("Bad file.")
    #
  }##IF.file.END
  
  #import the file    
  data.import <- read.csv(paste(myDir.data.import,strFile,sep="/"),as.is=TRUE,na.strings="")
  
  # add time period fields
  data.import[,"Year"] <- format(as.Date(data.import[,myName.Date]),format="%Y")
  data.import[,"YearMonth"] <- format(as.Date(data.import[,myName.Date]),format="%Y%m")
  data.import[,"MonthDay"] <- format(as.Date(data.import[,myName.Date]),format="%m%d")
  data.import[,"JulianDay"] <- as.POSIXlt(data.import[,myName.Date], format=myFormat.Date)$yday
  ## Season
  md <- data.import[,"MonthDay"]
  data.import[,"Season"] <- NA
  data.import[,"Season"][as.numeric(md)>=as.numeric("0101") & as.numeric(md)<as.numeric(myTimeFrame.Season.Spring.Start)] <- "Winter"
  data.import[,"Season"][as.numeric(md)>=as.numeric(myTimeFrame.Season.Spring.Start) & as.numeric(md)<as.numeric(myTimeFrame.Season.Summer.Start)] <- "Spring"
  data.import[,"Season"][as.numeric(md)>=as.numeric(myTimeFrame.Season.Summer.Start) & as.numeric(md)<as.numeric(myTimeFrame.Season.Fall.Start)] <- "Summer"
  data.import[,"Season"][as.numeric(md)>=as.numeric(myTimeFrame.Season.Fall.Start) & as.numeric(md)<as.numeric(myTimeFrame.Season.Winter.Start)] <- "Fall"
  data.import[,"Season"][as.numeric(md)>=as.numeric(myTimeFrame.Season.Winter.Start) & as.numeric(md)<as.numeric("1231")] <- "Winter"

  
  
  #
  # Loop - Parameter
  ## Temperature (Air/Water) 
  ## Flow (WaterLevel and Discharge)
  ## Nothing on Pressure
  
  # Define FUNCTION for use with summaryBy
  fun.sumby <- function(x, ...){##FUN.START
    c(min=min(x,na.rm=TRUE),avg=mean(x,na.rm=TRUE),max=max(x,na.rm=TRUE),var=var(x,na.rm=TRUE),range=max(x,na.rm=TRUE)-min(x,na.rm=TRUE))
  }##FUN.END
  #
  
  myParam <- myName.AirTemp
  
  # 0.3. avg by month+year (and n) - Temp
  data.import.avg.monthyear <- summaryBy(myName.AirTemp ~ myName.SiteID + month, data=data.import, FUN=mean, na.rm=TRUE)
  head(data.import.avg.monthyear)
  
  
  x <- summaryBy(myName.AirTemp ~ myName.SiteID, data=data.import, FUN=c(mean))
  
  
  # Loop - Time Frame (daily, monthly, seasonal, annual) (no water year only calendar year)
  
  
  
  ####################
  # old code - START
  ####################
  # force loading of needed libraries

  

  # Define FUNCTION for use with summaryBy
  fun.sumby <- function(x, ...){##FUN.START
    c(avg=mean(x, ...), n=length(x))
  }##FUN.END
  #
  fun.save <- function(myDF,myOutput) {##FUN.START
    write.table(myDF,file=myOutput,sep="\t",quote=FALSE,row.names=FALSE,col.names=TRUE)
  }##FUN.END
  
  # Define Counters for the LOOP
  myCounter.Start <- 1
  myCounter <- myCounter.Start
  myCounter.Stop = length(items2process)
  print(paste("Total items to process = ",myCounter.Stop-myCounter.Start+1,sep=""))
  
  #
  #
  #
  # 1. wrap data manipulation in a loop
  while (myCounter.Start < myCounter.Stop)
  { #LOOP.WHILE.START
    #
    # 0.1. import the data file
    myFile <- items2process[myCounter]
    mySep <- "\t"
    data.import <- read.table(myFile,header=T,mySep)
    # 
    # 0.2. Add Field = month from datetime
    data.import$month <- format.Date(data.import$datetime,"%m")
    head(data.import)
    #
    # Display progress to user (needs flush.console or only writes at end)
    # put here so some time between crunching the numbers and saving
    print(paste("Processing item ",myCounter," of ",myCounter.Stop-myCounter.Start+1,"; ",myFile,".",sep=""))
    flush.console()
    #
    # 0.3. avg Q by month+year (and n)
    data.import.avg.monthyear <- summaryBy(Q_mean_cfs ~ agency_cd + site_no + year + month, data=data.import, FUN=fun.sumby, na.rm=TRUE)
    head(data.import.avg.monthyear)
    # drop months with < 28 measurements
    data.import.avg.monthyear <- subset(data.import.avg.monthyear, Q_mean_cfs.n>=28)
    # rename columns
    colnames(data.import.avg.monthyear) <- c(colnames(data.import.avg.monthyear[,1:4]),"Q_mean_cfs","n")
    # 0.4. avg Q by year (and n)
    data.import.avg.year <- summaryBy(Q_mean_cfs ~ agency_cd + site_no + year, data=data.import.avg.monthyear, FUN=fun.sumby, na.rm=TRUE)
    head(data.import.avg.year)
    data.import.avg.year <- subset(data.import.avg.year, Q_mean_cfs.n==12)
    # rename columns
    colnames(data.import.avg.year) <- c(colnames(data.import.avg.year[,1:3]),"Q_mean_cfs","n")
    #
    # 0.5. avg Q by month (and n)
    data.import.avg.month <- summaryBy(Q_mean_cfs ~ agency_cd + site_no + month, data=data.import.avg.monthyear, FUN=fun.sumby, na.rm=TRUE)
    head(data.import.avg.month)
    # rename columns
    colnames(data.import.avg.month) <- c(colnames(data.import.avg.month[,1:3]),"Q_mean_cfs","n")
    
    # 0.6. Combine results into aggregate file
    # Exception for 1st iteration - create file
    if(myCounter==1) {##IF.START
      # create files on first iteration
      data.avg.monthyear  <- data.import.avg.monthyear
      data.avg.year       <- data.import.avg.year
      data.avg.month      <- data.import.avg.month  	
    }##IF.END
    if(myCounter>1) {##IF.START
      data.avg.monthyear.rbind  <- rbind(data.avg.monthyear, data.import.avg.monthyear)
      data.avg.monthyear        <- data.avg.monthyear.rbind 
      data.avg.year.rbind       <- rbind(data.avg.year, data.import.avg.year)
      data.avg.year             <- data.avg.year.rbind 
      data.avg.month.rbind      <- rbind(data.avg.month, data.import.avg.month)
      data.avg.month            <- data.avg.month.rbind 
    }##IF.END
    # 
    #
    # 0.7. Save the file (to same name as input file, i.e., overwrites orginal)
    fun.save(data.avg.monthyear ,paste("Gage.Summary.MonthYear.",myDate,".txt",sep=""))
    fun.save(data.avg.year      ,paste("Gage.Summary.Year.",myDate,".txt",sep=""))
    fun.save(data.avg.month     ,paste("Gage.Summary.Month.",myDate,".txt",sep=""))
    # Display progress to user
    print(paste("Saving output ",myCounter," of ",myCounter.Stop-myCounter.Start+1,"; ",myFile,".",sep=""))
    flush.console() 
    #
    # 0.8. Some clean up
    rm(data.import)
    # Increase the Counter
    myCounter <- myCounter+1
  }##LOOP.WHILE.END
  
  print(paste("Processing complete; ",myCounter-1," of ",myCounter.Stop," items.",sep=""))
  print(paste("Last item processed = ",items2process[myCounter-1],".",sep="")) #use for troubleshooting if get error
  alarm()
  
    ####################
    # old code - END
    ####################
  
  
  #
}##FUN.fun.Stats.END
########################
